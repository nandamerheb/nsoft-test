<?php
if(!empty($_GET['sent'])){
?>
<div style="text-align:center;font-size=20px;margin-top:10%;">
    Your amount was sent!
</div>
<?php
}
?>
<form action="sender.php" method="POST" style="text-align:center;font-size=20px;margin-top:5%;">
    <div style="margin-top:20px;">
        <label>Amount</label>
        <br>
        <input type="text" name="amount" id="amount" />
    </div>
    <div style="margin-top:20px;">
        <label>Currency</label>
        <br>
        <input type="text" name="currency" id="currency" />
    </div>
    <div style="margin-top:20px;">
        <button type="submit">Send</button>
    </div>
</form>
