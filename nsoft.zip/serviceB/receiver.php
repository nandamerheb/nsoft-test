<?php
session_start();
session_destroy();
session_start();

$_SESSION['amountStorage'] = 0;

require_once __DIR__ . '/vendor/autoload.php';
use PhpAmqpLib\Connection\AMQPConnection;


try {

$connection = new AMQPConnection('localhost', 5672, 'guest', 'guest');
$channel = $connection->channel();

$channel->queue_declare('ammount_storage', false, false, false, false);

echo ' * Waiting for amount. To exit press CTRL+C', "\n";

$callback = function($msg){


    $data = json_decode($msg->body, true);

    $amount = $data['amount'];
    $currency = $data['currency'];

   if($currency =="EUR" || $currency == "eur")
   {
       echo " * Amount received", "\n";

   		$storage = $_SESSION['amountStorage'];

   		if($storage > 0)
   		{

   		  if($amount > 0)
   		  {
   		  	//Ako je veci od 0 dodajemo ga na storage
   		  	$storage+=$amount;
   		  }
   		  else
   		  {
   		  	if(abs($amount) <= $storage)
   		  	{
            //Ako je manji ili jednak trenutnom iznosi na storage umanjiti storage za taj iznos
            $storage = $storage - abs($amount);
   		  	}
   		  }
   		}
   		else
   		{
   			if($amount > 0)
   		  {
   		  	//Ako je storage 0 onda je moguce samo dodati na njega
   		  	$storage+=$amount;
   		  }
   		}

		//Spasavanje nove vrijednosti storage-a
   		$_SESSION["amountStorage"] = $storage;

      echo " * Your storage amount is", "\n";
        echo $_SESSION["amountStorage"];
        echo "\n";
   }

    $msg->delivery_info['channel']->basic_ack($msg->delivery_info['delivery_tag']);
};

$channel->basic_qos(null, 1, null);
$channel->basic_consume('ammount_storage', '', false, false, false, false, $callback);

while(count($channel->callbacks)) {
    $channel->wait();
}
}
catch(Exception $e) {
  echo 'Error: ' .$e->getMessage();
}
