<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/vendor/autoload.php';
use PhpAmqpLib\Connection\AMQPConnection;
use PhpAmqpLib\Message\AMQPMessage;

class ServiceBTest extends TestCase
{
    public function testAdd()
    {
      $connection = new AMQPConnection('localhost', 5672, 'guest', 'guest');
     $channel = $connection->channel();

     $channel->queue_declare('ammount_storage', false, false, false, false);


     $dataPost['amount']=50;
     $dataPost['currency'] = "EUR";

     $data = json_encode($dataPost);

     $msg = new AMQPMessage($data, array('delivery_mode' => 2));
     $channel->basic_publish($msg, '', 'ammount_storage');
    }

    public function testRemove()
    {
      $connection = new AMQPConnection('localhost', 5672, 'guest', 'guest');
     $channel = $connection->channel();

     $channel->queue_declare('ammount_storage', false, false, false, false);


     $dataPost['amount']=-50;
     $dataPost['currency'] = "EUR";

     $data = json_encode($dataPost);

     $msg = new AMQPMessage($data, array('delivery_mode' => 2));
     $channel->basic_publish($msg, '', 'ammount_storage');
    }

    public function testWrongCurrency()
    {
      $connection = new AMQPConnection('localhost', 5672, 'guest', 'guest');
     $channel = $connection->channel();

     $channel->queue_declare('ammount_storage', false, false, false, false);


     $dataPost['amount']=-50;
     $dataPost['currency'] = "BAM";

     $data = json_encode($dataPost);

     $msg = new AMQPMessage($data, array('delivery_mode' => 2));
     $channel->basic_publish($msg, '', 'ammount_storage');
    }
}
?>
